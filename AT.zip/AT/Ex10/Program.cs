﻿class Ex10
{
    static void Main(string[] args)
    {
        //Utilizando a class Random crio uma variavel que armazena um número no intervalo entre 1 e 51 (o 51 não é incluído)
        Random aleatorio = new Random();
        int numeroAleatorio = aleatorio.Next(1, 51);

        //variavel para contabilizar as tentativas
        int tentativas = 0;

        Console.WriteLine("Jogo de Adivinhação");

        //Utilizando o while para permanecer na repetição enquanto o número de tentativas for menor que 5
        while (tentativas < 5)
        {
            Console.WriteLine("\nTente adivinhar o número secreto de 1 a 50:");
            int numero = int.Parse(Console.ReadLine());

            //Condicional para exibir mensagem caso o número digitado não pertencer ao grupo de números no intervalo entre 1 e 51
            if (numero <= 0 || numero > 50)
            {
                Console.WriteLine("\nNúmero invalido, tente novamente");
                continue;
            }
            else
            {
                //Condicionais para exibir feedback se o usuário acertou ou errou, se errar adiciona +1 ao total de tentativas
                if (numero == numeroAleatorio)
                {
                    Console.WriteLine("\nParabéns, você acertou!");
                    return;
                }
                else
                {
                    Console.WriteLine("\nVocê Errou!");
                    tentativas++;

                    //Se ainda existirem tentativas restantes exibir a respectiva dica 
                    if (tentativas < 5)
                    {
                        if (numeroAleatorio > numero)
                        {
                            Console.WriteLine($"Dica: o número secreto é maior que {numero}, você ainda tem {5 - tentativas} tentativas restantes");
                            continue;
                        }
                        else if (numeroAleatorio < numero)
                        {
                            Console.WriteLine($"Dica: o número secreto é menor que {numero}, você ainda tem {5 - tentativas} tentativas restantes");
                            continue;
                        }
                        //Se não existir nenhuma tentativa restante, exibir mensagem de derrota
                    }
                    else
                    {
                        Console.WriteLine($"\nVocê Perdeu! o número secreto era o {numeroAleatorio}");
                    }

                }
            }
        }
    }
}