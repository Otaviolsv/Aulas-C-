﻿class Ex4
{
    static void Main(string[] args)
    {
        //Entrada do usuário
        Console.WriteLine("Informe o dia do seu aniversário");
        var diaAniversario = int.Parse(Console.ReadLine());
        Console.WriteLine("Informe o mês do seu aniversário");
        var mesAniversario = int.Parse(Console.ReadLine());
        Console.WriteLine("Informe o ano do seu aniversário");
        var anoAniversario = int.Parse(Console.ReadLine());

        var dataAtual = DateTime.Today;
        var anoAtual = dataAtual.Year;

        //Data de aniversario do ano atual
        var aniversarioAtual = new DateTime(anoAtual, mesAniversario, diaAniversario);


        //Se o aniversário já passou esse ano, adiciona mais um ano para o aniversarioAtual
        if (aniversarioAtual < dataAtual)
        {
            aniversarioAtual = aniversarioAtual.AddYears(1);
        }

        var diasRestantes = (aniversarioAtual - dataAtual).TotalDays;

        Console.WriteLine("");
        Console.WriteLine($"Faltam {(int)diasRestantes} para o seu aniversario!");

        //Mensagem especial se faltar menos de 7 dias para o aniversário
        if ((int)diasRestantes > 0 && (int)diasRestantes < 7)
        {
            Console.WriteLine("Wow seu aniversário está bem próximo!");
        }
        //Mensagem especial se o aniversário for hoje 
        else if ((int)diasRestantes == 0)
        {
            Console.WriteLine("Parabéns hoje é o seu aniversário!");
        }

    }
}