﻿class Ex8
{
    //Classe funcionario com os atributos solicitados
    class Funcionario
    {
        public String nome;
        public String cargo;
        public double salarioBase;

        //Metodo virtual para retornar o salario que permite ser sobrescrito
        public virtual double Salario()
        {
            return salarioBase;
        }

        //Metodo para exibir os dados do funcionario 
        public void ExibirDados()
        {
            Console.WriteLine($"Nome: {nome}");
            Console.WriteLine($"Cargo: {cargo}");
            Console.WriteLine($"Salario: R${Salario()}");
        }
    }

    //Subclasse gerente 
    class Gerente : Funcionario
    {
        //Subscreve o metodo Salario adicionando 20% ao salarioBase
        public override double Salario()
        {
            return salarioBase = salarioBase + (salarioBase * 0.20);
        }

    }
    static void Main(string[] args)
    {
        //Criação de objeto para funcionario
        Funcionario funcionario1 = new Funcionario()
        {
            nome = "Otávio Vasconcelos",
            cargo = "Assistente",
            salarioBase = 1500
        };
        //Criação de objeto para gerente
        Gerente funcionario2 = new Gerente()
        {
            nome = "Anderson Barbosa",
            cargo = "Gerente TI",
            salarioBase = 1500
        };

        funcionario1.ExibirDados();
        Console.WriteLine("");
        funcionario2.ExibirDados();
    }
}