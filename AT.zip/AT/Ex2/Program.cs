﻿class Ex2
{
    static void Main(string[] args)
    {
        Console.Write("Digite seu nome completo: ");
        string nome = Console.ReadLine();
        char[] letrasAlteradas = new char[nome.Length];

        //laço de repetição for para percorrer cada letra do nome
        for (int i = 0; i < nome.Length; i++)
        {
            //Armazena as letras  
            char letra = nome[i];

            //Condicional se for uma letra
            if (char.IsLetter(letra))
            {
                //Define se a letra for maiuscula e armazena corretamente para a variavel baseLetra
                char baseLetra = char.IsUpper(letra) ? 'A' : 'a';

                //Adiciona + 2 na posição de letras 
                letra = (char)(baseLetra + (letra - baseLetra + 2) % 26);
            }

            //Percorre cada letra que foi adicionada +2 em sua posição e armazena na variavel letrasAlteradas
            letrasAlteradas[i] = letra;
        }

        string resultado = new string(letrasAlteradas);
        Console.WriteLine("Saída: " + resultado);
    }
}