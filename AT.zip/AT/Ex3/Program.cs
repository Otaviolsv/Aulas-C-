﻿class Ex3
{
    static void Main(string[] args)
    {

        //Entrada do usuário
        Console.WriteLine("Informe o primeiro número");
        int n1 = int.Parse(Console.ReadLine());
        Console.WriteLine("Informe o segundo número");
        int n2 = int.Parse(Console.ReadLine());

        Console.WriteLine("Escolha uma operação matemática: [Soma(1), Subtracao(2), Multiplicacao(3) ou Divisao(4)]");
        String operacao = Console.ReadLine();

        int resultado = 0;

        //Condicionais validando a operacao e realizando o calculo correto
        if (operacao.Equals("1"))
        {
            Console.WriteLine("");
            resultado = n1 + n2;
            Console.WriteLine($"{n1} + {n2} = {resultado}");
        }
        else if (operacao.Equals("2"))
        {
            Console.WriteLine("");
            resultado = n1 - n2;
            Console.WriteLine($"{n1} - {n2} = {resultado}");
        }
        else if (operacao.Equals("3"))
        {
            Console.WriteLine("");
            resultado = n1 * n2;
            Console.WriteLine($"{n1} x {n2} = {resultado}");
        }
        else if (operacao.Equals("4"))
        {
            if (n2 == 0)
            {
                Console.WriteLine("");
                Console.WriteLine("Não é possível dividir por zero");
            }
            else
            {
                Console.WriteLine("");
                resultado = n1 / n2;
                Console.WriteLine($"{n1} / {n2} = {resultado}");
            }
        }
        //Feedback informando valor invalido de operacao
        else
        {
            Console.WriteLine("");
            Console.WriteLine("Operacao invalida, tente novamente!");
        }
    }
}