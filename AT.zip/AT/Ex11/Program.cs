﻿class Ex11
{
    //Classe com atributos array solicitados, nome do arquivo.txt e contador para contabilizar o número de contatos
    class Contatos
    {
        private const string arquivo = "Contatos.txt";

        public String[] nome = new string[30];
        public String[] telefone = new String[30];
        public String[] email = new String[30];
        private int contador = 0;

        //Metodo utilizando laço de repetição while para permanecer na tela de Menu no console até o break
        public void Menu()
        {
            //Condicional se existir arquivo
            if (File.Exists(arquivo))
            {
                //StreamReade para abrir o arquivo para leitura
                using (StreamReader reader = new StreamReader(arquivo))
                {
                    string linha;

                    //Laço de repetição while para ler arquivo até o final (null) 
                    while ((linha = reader.ReadLine()) != null)
                    {
                        //Utilizando o Split para separar os dados por ,
                        string[] dados = linha.Split(',');

                        //Condicional se a linha conter 3 elementos, armazena os dados nos arrays e incrementa o contador
                        if (dados.Length == 3)
                        {
                            nome[contador] = dados[0];
                            telefone[contador] = dados[1];
                            email[contador] = dados[2];
                            contador++;
                        }
                    }
                }
            }
            while (true)
            {
                Console.WriteLine("=== Gerenciador de Contatos ===");
                Console.WriteLine("\n1 - Adicionar novo contato");
                Console.WriteLine("2 - Listar contatos cadastrados");
                Console.WriteLine("3 - Sair");
                Console.WriteLine("");

                int opcao = int.Parse(Console.ReadLine());

                //Condicional se o usuário escolher a opção 1
                if (opcao == 1)
                {

                    Console.WriteLine("\nInserindo produto");

                    Console.WriteLine("\nDigite o nome do contato:");
                    nome[contador] = Console.ReadLine();
                    Console.WriteLine("\nDigite a telefone do contato:");
                    telefone[contador] = Console.ReadLine();
                    Console.WriteLine("\nDigite o e-mail do contato:");
                    email[contador] = Console.ReadLine();
                    Console.WriteLine("");

                    //StreamWriter para inserir os dados no arquivo contatos.txt
                    using (StreamWriter writer = File.AppendText(arquivo))
                    {

                        writer.WriteLine($"{nome[contador]},{telefone[contador]},{email[contador]}");
                    }

                    //Adiciona +1 ao contador e continua para a repetição do while no Menu
                    contador++;
                    continue;


                }
                //Condicional se o usuário escolher a opção 2
                if (opcao == 2)
                {
                    //Laço de repetição while para permanecer na lista de contatos no console até o break
                    while (true)
                    {
                        Console.WriteLine("=== Contatos cadastrados: === ");
                        Console.WriteLine("");

                        //Laço de repetição for para exibir os arrays dos contatos no console até o número do contador
                        for (int i = 0; i < contador; i++)
                        {
                            Console.WriteLine($"{i + 1}. Nome:{nome[i]} | Telefone:{telefone[i]} | E-mail:{email[i]}");
                            Console.WriteLine("");
                        }

                        Console.WriteLine("Digite 3 se deseja voltar para o menu");
                        int opcao2 = int.Parse(Console.ReadLine());

                        //Condicional se o usuário não escolher a opção 3 continua na tela de lista
                        if (opcao2 != 3)
                        {
                            continue;
                        }
                        //Se o usuário escolher a opção 3 sai do laço de repetição da lista de contatos e volta para o Menu
                        else
                        {
                            Console.WriteLine("");
                            break;
                        }
                    }
                }
                //Condicional se o usuário escolher a opção 3 sai do laço de repetição do Menu
                if (opcao == 3)
                {
                    break;
                }
            }

            Console.WriteLine("\nAdeus!");
        }

        static void Main(string[] args)
        {
            //Condicional se não existir o arquivo, criar arquivo
            //Exemplo endereço de aquivo:  C:\Users\Otávio\source\repos\AT\AT\bin\Debug\net8.0\contatos.txt
            if (!File.Exists(arquivo))
            {
                using (File.Create(arquivo)) { }
            }

            //Criando objeto contatos
            Contatos contatos = new Contatos();

            //Chamando o metodo Menu de contatos
            contatos.Menu();
        }
    }
}