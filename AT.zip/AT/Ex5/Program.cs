﻿class Ex5
{
    static void Main(string[] args)
    {

        //Entrada solicitando a data atual para o usuário
        Console.WriteLine("Digite a data atual (dd/MM/yyyy):");
        var dataEntrada = DateTime.Parse(Console.ReadLine());

        //Variavel com a data atual
        var dataAtual = DateTime.Today;

        //Definido a data da formatura
        DateTime dataFormatura = new DateTime(2026, 12, 15);

        //Condicional que trata caso o usuário informe a data superior a real data atual do sistema
        if (dataEntrada > dataAtual)
        {
            Console.WriteLine("");
            Console.WriteLine($"Atenção: A data atual informada é no futuro!");
        }

        //Variavel com o total de dias restantes para a formatura
        var tempoRestante = (dataFormatura - dataEntrada).TotalDays;

        //Transformando total de dias até a formatura em anos, meses e dias
        int anos = (int)tempoRestante / 365;
        int meses = ((int)tempoRestante % 365) / 30;
        int dias = ((int)tempoRestante % 365) % 30;

        //Condicionais para informar ao usuário se ele já deveria estar formado ou quanto tempo falta até a formatura e a mensagem especial caso falte menos de 6 meses até a formatura
        if (dataEntrada > dataFormatura)
        {
            Console.WriteLine("");
            Console.WriteLine($"Você já deveria estar formado na data {dataEntrada}");
        }
        else
        {
            Console.WriteLine("");
            Console.WriteLine($"Faltam {anos} anos, {meses} meses e {dias} dias para sua formatura na data {dataFormatura.ToString("dd/MM/yyyy")}!");

            if (anos == 0 && meses < 6)
            {
                Console.WriteLine("");
                Console.WriteLine("A reta final chegou! Prepare-se para a formatura!");

            }
        }
    }
}