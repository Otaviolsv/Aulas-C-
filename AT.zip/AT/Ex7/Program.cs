﻿class Ex7
{
    //Classe com os atributos solicitados
    class ContaBancaria
    {
        public String titular;
        private decimal saldo;

        //Metodo para depositar valor (adicionar o "valor" ao "saldo")
        public void Depositar(decimal valor)
        {
            //Condicional para somente depositar caso o valor for maior que 0
            if (valor <= 0)
            {
                Console.WriteLine("");
                Console.WriteLine($"Deposito de R${valor} inválido, o valor precisa ser maior que zero!");
            }
            else
            {
                saldo = saldo + valor;
                Console.WriteLine("");
                Console.WriteLine($"Deposito de R${valor} realizado!");
            }
        }
        //Metodo para sacar valor (subtrair o "valor" do "saldo")
        public void Sacar(decimal valor)
        {
            //Condicional para somente sacar se valor for menor ou igual ao saldo
            if (valor > saldo)
            {
                Console.WriteLine("");
                Console.WriteLine($"Saque de R${valor} inválido, saldo insuficiente!");
            }
            else
            {
                saldo = saldo - valor;
                Console.WriteLine("");
                Console.WriteLine($"Saque de R${valor} realizado!");
            }
        }
        //Metodo para exibir o saldo atual
        public void ExibirSaldo()
        {
            Console.WriteLine("");
            Console.WriteLine($"Saldo atual: R${saldo}");
        }
    }
    static void Main(string[] args)
    {
        ContaBancaria conta1 = new ContaBancaria()
        {
            titular = "Otávio Vasconcelos"
            //exemplo de uso de alterar o saldo manualmente erro(inacessível)
            //saldo = 1000
        };

        //Simulando transações 
        Console.WriteLine($"Titular: {conta1.titular}");
        conta1.Depositar(500);
        conta1.ExibirSaldo();
        conta1.Sacar(800);
        conta1.Sacar(260);
        conta1.ExibirSaldo();

    }
}