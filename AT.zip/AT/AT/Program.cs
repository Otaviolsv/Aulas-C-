﻿
//EX1
class Ex1
{
    static void Main(string[] args)
    {
        Console.WriteLine("olá, meu nome é otávio vasconcelos");
        Console.WriteLine("nasci em 09/08/2002 e estou aprendendo c#");
    }
}





