﻿class Ex6
{
    //Classe Aluno com os atributos solicitados
    class Aluno
    {
        public String nome;
        public int matricula;
        public String curso;
        public double mediaNotas;

        //Metodo para exibir os dados da classe Aluno
        public void ExibirDados()
        {
            Console.WriteLine($"Nome: {nome}");
            Console.WriteLine($"Matrícula: {matricula}");
            Console.WriteLine($"Curso: {curso}");
            Console.WriteLine($"Média Notas: {mediaNotas}");
        }

        //Metodo utilizando condicional se a nota for menor que 7 reprovado se não aprovado.
        public String VerificarAprovacao()
        {
            String resultado;
            if (mediaNotas >= 7)
            {
                resultado = "Aprovado";
            }
            else
            {
                resultado = "Reprovado";
            }
            return resultado;
        }

    }
    //Criação de um objeto aluno1
    static void Main(string[] args)
    {
        Aluno aluno1 = new Aluno()
        {
            nome = "Otávio Vasconcelos",
            matricula = 12345,
            curso = "Engenharia de Software",
            mediaNotas = 10
        };

        aluno1.ExibirDados();
        Console.WriteLine($"Resultado: {aluno1.VerificarAprovacao()}");
    }
}